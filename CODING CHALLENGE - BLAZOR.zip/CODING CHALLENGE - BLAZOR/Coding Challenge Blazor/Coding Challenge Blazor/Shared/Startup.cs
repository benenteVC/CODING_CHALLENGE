﻿using Microsoft.AspNetCore.Mvc;

namespace Coding_Challenge_Blazor.Shared
{
    public class Startup : Controller
    {



    }
}
