﻿using Microsoft.AspNetCore.Mvc;

namespace Coding_Challenge_Blazor.Data
{
    public class User
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }


    }

    public class Login
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
