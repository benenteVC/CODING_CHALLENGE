Thank you for given me the chance to show you what i am capible to do!

With being a fresh graduate and never working with Xamarin and Blazor before, I did find this challenge a bit difficult.
I did work to the best of my ability to show you what I am able to do.

XAMARIN
My code unfortunatley did not run but all backend/frontend code is visible for you to see and can show all steps that I
took to get the outcome that was requsted. I did really enjoy using Xamarin and have learnt a lot from this challange.
I know with more learning and effort, I will be able to make soething great out of it.

BLAZOR
My code was not able to run and I had a few bugs that I was unable to locate and fix. This was my first time using and learning
Blazor and with some more time and effort, I am positive that some great can be made from it.


I am a hardworking indiviual that will do anything that comes to hand. I am willing to learn and show your company exactly
what I am made of!!


- Benjamin Ente

